import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";

export default function PrayerTime() {
  const [times, setTimes] = useState(null);

  useEffect(() => {
    fetch("https://api.aladhan.com/v1/timingsByCity?city=Dhaka&country=Bangladesh&method=1")
      .then(res => res.json())
      .then(data => setTimes(data.data.timings));
  }, []);

  return (
    <div className="p-6">
      <Navbar />
      <h1 className="text-xl font-bold mb-4">Prayer Times</h1>
      {times ? (
        <ul className="space-y-1">
          {Object.entries(times).map(([name, time]) => (
            <li key={name}><strong>{name}</strong>: {time}</li>
          ))}
        </ul>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}