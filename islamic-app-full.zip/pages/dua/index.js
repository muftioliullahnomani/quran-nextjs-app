import Navbar from "@/components/Navbar";

const duas = [
  { title: "Morning Dua", text: "اللّهـمَّ أَصْـبَـحْنا..." },
  { title: "Before Sleep", text: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا" }
];

export default function Dua() {
  return (
    <div className="p-6">
      <Navbar />
      <h1 className="text-xl font-bold mb-4">Daily Duas</h1>
      <ul className="space-y-3">
        {duas.map((d, i) => (
          <li key={i} className="border p-2 rounded">
            <h3 className="font-semibold">{d.title}</h3>
            <p>{d.text}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}