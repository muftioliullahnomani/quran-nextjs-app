import Navbar from "@/components/Navbar";

export default function Home() {
  return (
    <div className="p-6 font-sans">
      <Navbar />
      <h1 className="text-2xl font-bold my-4">Welcome to Islamic App</h1>
      <p>Explore Qur'an, Hadith, Duas, and Prayer Times.</p>
    </div>
  );
}