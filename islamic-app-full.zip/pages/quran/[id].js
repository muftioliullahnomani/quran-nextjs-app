import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Navbar from "@/components/Navbar";

export default function Surah() {
  const router = useRouter();
  const { id } = router.query;
  const [surah, setSurah] = useState(null);

  useEffect(() => {
    if (id) {
      fetch(`https://api.alquran.cloud/v1/surah/${id}/bn.bengali`)
        .then(res => res.json())
        .then(data => setSurah(data.data));
    }
  }, [id]);

  if (!surah) return <div className="p-6">Loading...</div>;

  return (
    <div className="p-6">
      <Navbar />
      <h2 className="text-xl font-bold mb-2">{surah.englishName} ({surah.name})</h2>
      <ul className="space-y-3">
        {surah.ayahs.map(ayah => (
          <li key={ayah.number}>
            <p className="text-lg">{ayah.text}</p>
            <audio controls src={`https://cdn.islamic.network/quran/audio/64/ar.alafasy/${ayah.number}.mp3`} />
          </li>
        ))}
      </ul>
    </div>
  );
}