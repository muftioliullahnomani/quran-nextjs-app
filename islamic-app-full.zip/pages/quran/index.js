import Link from 'next/link';
import { useEffect, useState } from 'react';
import Navbar from "@/components/Navbar";

export default function Quran() {
  const [surahs, setSurahs] = useState([]);

  useEffect(() => {
    fetch('https://api.alquran.cloud/v1/surah')
      .then(res => res.json())
      .then(data => setSurahs(data.data));
  }, []);

  return (
    <div className="p-6">
      <Navbar />
      <h1 className="text-xl font-bold mb-4">Surahs</h1>
      <ul className="space-y-2">
        {surahs.map(surah => (
          <li key={surah.number}>
            <Link href={`/quran/${surah.number}`}>
              <span className="underline cursor-pointer">
                {surah.englishName} ({surah.name})
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}