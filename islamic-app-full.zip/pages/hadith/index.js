import Navbar from "@/components/Navbar";

const hadithList = [
  { source: "Bukhari", text: "Actions are judged by intentions." },
  { source: "Muslim", text: "The best among you are those who have the best manners." }
];

export default function Hadith() {
  return (
    <div className="p-6">
      <Navbar />
      <h1 className="text-xl font-bold mb-4">Hadith Collection</h1>
      <ul className="space-y-2">
        {hadithList.map((h, i) => (
          <li key={i} className="border p-2">
            <p>"{h.text}"</p>
            <small>- {h.source}</small>
          </li>
        ))}
      </ul>
    </div>
  );
}