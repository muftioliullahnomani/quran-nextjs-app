import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="mb-6 flex gap-4 border-b pb-2 text-blue-700 font-semibold">
      <Link href="/">Home</Link>
      <Link href="/quran">Qur'an</Link>
      <Link href="/hadith">Hadith</Link>
      <Link href="/dua">Dua</Link>
      <Link href="/prayer-time">Prayer Time</Link>
    </nav>
  );
}